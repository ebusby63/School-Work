package project_EoinBusby_40365970;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class Part3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
	/**Part 3a
	 * This method reads a text file and then finds how many times the word input into string wally 
	 * is written in the text file vertically and outputs the last line which is occurs
	 * 
	 * @param fileName
	 * @param wally
	 * @return
	 */
	public static int wheresWally1(String fileName, String wally) {
		int NoOfWally = 0;
		int row = 0;
		int rowCounter = 0;
		String[] fileArray;
		String line = null;
		String line1 = null;
		try {
			File file = new File(fileName);
			FileReader fileReader = new FileReader(file.getName());
			BufferedReader bufferReader = new BufferedReader(fileReader);
			line = bufferReader.readLine();
			while (line != null) {
				row++;
				line = bufferReader.readLine();
			}
			fileReader.close();
			bufferReader.close();
			fileArray = new String[row];
			FileReader fileReader1 = new FileReader(file.getName());
			BufferedReader bufferReader1 = new BufferedReader(fileReader1);
			line1 = bufferReader1.readLine();
			while (line1 != null) {
				fileArray[rowCounter] = line1;
				if (rowCounter < row) {
					rowCounter++;
				}
				line1 = bufferReader1.readLine();
			}
			int lastPosition = 0;
			rowCounter = 0;
			do {
				for (int i = 0; i < fileArray[rowCounter].length(); i++) {
					if (Part1.isSameLetterIgnoreCase(fileArray[rowCounter].charAt(i), wally.charAt(0))) {
						for (int j = 1; j < wally.length(); j++) {
							if (fileArray[rowCounter + j].length() < i + 1) {
								break;
							}
							if (Part1.isSameLetterIgnoreCase(fileArray[rowCounter + j].charAt(i), wally.charAt(j))) {
								if (Part1.isSameLetterIgnoreCase(fileArray[rowCounter + j].charAt(i),
										wally.charAt(wally.length() - 1))) {
									if (j == wally.length() - 1)
										NoOfWally++;
									lastPosition = rowCounter + 1;
								}

							} else {
								break;
							}
						}
					}
				}
				rowCounter++;
			} while (rowCounter < row);
			System.out.println("Position of last occurrence= " + lastPosition);
			fileReader1.close();
			bufferReader1.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (StringIndexOutOfBoundsException e) {
			e.printStackTrace();
		}

		return NoOfWally;

	}
}