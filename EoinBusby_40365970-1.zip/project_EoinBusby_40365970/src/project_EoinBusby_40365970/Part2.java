package project_EoinBusby_40365970;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class Part2 extends Part1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
	/**
	 * Part 2a 
	 * This method shifts a string to the right by the amount of letter input into the shift variable
	 * 
	 * @param s
	 * @param shift
	 * @return
	 */
	public static String caesarEncrypt(String s, int shift) {
		String cypher = "";
		for (int i = 0; i < s.length(); i++) {
			char c = s.charAt(i);
			if (c >= 'a' && c <= 'z') {
				int originalAlphabetPosition = c - 'a';
				int newAlphabetPosition = (originalAlphabetPosition + shift) % 26;
				char encryptedChar = (char) ('a' + newAlphabetPosition);
				cypher = cypher + encryptedChar;
			}
			if (c >= 'A' && c <= 'Z') {
				int originalAlphabetPosition = c - 'A';
				int newAlphabetPosition = (originalAlphabetPosition + shift) % 26;
				char encryptedChar = (char) ('A' + newAlphabetPosition);
				cypher = cypher + encryptedChar;
			}
			if (isLetter(c) == false) {
				cypher = cypher + c;
			}
		}
		return cypher;
	}

	/**
	 * Part 2b 
	 * This shifts a string left by the number of letters input into the shift variable
	 * 
	 * @param s
	 * @param shift
	 * @return
	 */
	public static String caesarDecrypt(String s, int shift) {
		String cypher = "";
		int leftShift = 26 - (shift % 26);
		for (int i = 0; i < s.length(); i++) {
			char c = s.charAt(i);
			if (c >= 'a' && c <= 'z') {
				int originalAlphabetPosition = c - 'a';
				int newAlphabetPosition = 26 - ((originalAlphabetPosition + leftShift) % 26);
				char encryptedChar = (char) ('a' + newAlphabetPosition);
				cypher = cypher + encryptedChar;
			}
			if (c >= 'A' && c <= 'Z') {
				int originalAlphabetPosition = c - 'A';
				int newAlphabetPosition = 26 - ((originalAlphabetPosition + leftShift) % 26);
				char encryptedChar = (char) ('A' + newAlphabetPosition);

				cypher = cypher + encryptedChar;
			}
			if (isLetter(c) == false) {
				cypher = cypher + c;
			}
		}
		return cypher;
	}

	/**
	 * Part 2c 
	 * This method counts the how many times a specific word that's input into the 
	 * s string appeared in a text file 
	 * 
	 * @param fileName
	 * @param s
	 * @return
	 */
	public static int countWordOccurences(String fileName, String s) {
		int noOfOccurences = 0;
		String line;
		try {
			File f = new File(fileName);
			FileReader fileReader = new FileReader(f.getName());
			BufferedReader bufferReader = new BufferedReader(fileReader);
			line = bufferReader.readLine();
			while (line != null) {
				String[] lineArray = line.split(" ");
				for (int i = 0; i < lineArray.length; i++) {
					if (lineArray[i].toLowerCase().equals(s)) {
						noOfOccurences++;
					}
				}
				line = bufferReader.readLine();
			}
			bufferReader.close();
			fileReader.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return noOfOccurences;
	}

	/**
	 * Part 2d 
	 * This method reads a file and looks for a specific word input into the oldWord string and then replaces it
	 * with the word input into the newWord string and writes it into a new file while keeping the case of the 
	 * first letter in the changed word
	 * 
	 * 
	 * @param oldFileName
	 * @param newFileName
	 * @param oldWord
	 * @param newWord
	 */
	public static void replaceWordOccurences(String oldFileName, String newFileName, String oldWord, String newWord) {
		String newLine;
		String oldWordCaseChange;
		String newWordCaseChange;
		String line;
		int oldCaseChange = 0;
		int newCaseChange = 0;
		if (oldWord.charAt(0) >= 'a') {
			oldCaseChange = (oldWord.charAt(0) - 32);
			oldWordCaseChange = (char) (oldCaseChange) + oldWord.substring(1);
		} else {
			oldCaseChange = (oldWord.charAt(0) + 32);
			oldWordCaseChange = (char) (oldCaseChange) + oldWord.substring(1);
		}
		if (newWord.charAt(0) >= 'a') {
			newCaseChange = (newWord.charAt(0) - 32);
			newWordCaseChange = (char) (newCaseChange) + newWord.substring(1);
		} else {
			newCaseChange = (newWord.charAt(0) + 32);
			newWordCaseChange = (char) (newCaseChange) + newWord.substring(1);
		}
		try {
			File oldFile = new File(oldFileName);
			File newFile = new File(newFileName);
			if (!newFile.exists()) {
				newFile.createNewFile();
			}
			FileReader oldFileReader = new FileReader(oldFile.getName());
			BufferedReader bufferReader = new BufferedReader(oldFileReader);
			line = bufferReader.readLine();
			FileWriter newFileWriter = new FileWriter(newFile, true);
			BufferedWriter bw = new BufferedWriter(newFileWriter);
			while (line != null) {
				newLine = line.replace(oldWord, newWord);
				newLine = newLine.replace(oldWordCaseChange, newWordCaseChange);
				bw.write(newLine + "\n");
				line = bufferReader.readLine();
			}
			bw.close();
			newFileWriter.close();
			bufferReader.close();
			oldFileReader.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
}
