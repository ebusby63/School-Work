package project_EoinBusby_40365970;

import java.util.Arrays;

public class Part1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	}
	/**
	 * Part 1a 
	 * This method takes two char values and checks that they are inside the ascii values 
	 * for letters
	 * 
	 * @param ch
	 * @return
	 */
	public static boolean isLetter(char ch) {
		boolean letter;
		if ((ch >= 'a' && ch <= 'z') || (ch >= 'A' && ch <= 'Z')) {
			letter = true;
		} else {
			letter = false;
		}
		return letter;
	}

	/**
	 * Part 1b 
	 * The method checks the value of two char values against each other to check if they are 
	 * the same and to ignore the case difference between them 
	 * 
	 * @param ch1
	 * @param ch2
	 * @return
	 */
	public static boolean isSameLetterIgnoreCase(char ch1, char ch2) {
		String letter1 = String.valueOf(ch1);
		String letter2 = String.valueOf(ch2);
		return letter1.equalsIgnoreCase(letter2);
	}

	/**
	 * Part 1c 
	 * This method iterates through a string and looks for the longest word in that string by comparing
	 * lengths of two separate strings one that temporally holds a string and the other that stores the current
	 * longest word
	 * 
	 * @param s
	 * @return
	 */
	public static String longestWord(String s) {
		String longestWord = "";
		String currentWord = "";

		for (int counter = 0; counter < s.length(); counter++) {
			if (isLetter(s.charAt(counter)) == true) {
				currentWord += s.charAt(counter);
			} else {
				if (longestWord.length() < currentWord.length())
					longestWord = currentWord;
			}
			currentWord = "";
		}
		return currentWord;
	}

	/**
	 * Part 1d 
	 * This method counts all of the unique letters in a string then returns the
	 * number of letters that were unique 
	 * 
	 * @param s
	 * @return
	 */
	public static int countDifferentLetters(String s) {
		s = s.toLowerCase();
		String onlyLetters = "";
		int totalUniqueLetters = 0;
		for (int index = 0; index < s.length(); index++) {
			if (isLetter(s.charAt(index)) == true) {
				onlyLetters += s.charAt(index);
			}
		}
		for (int index = 0; index < onlyLetters.length(); index++) {
			if (onlyLetters.charAt(index) != ' ')
				totalUniqueLetters++;
			onlyLetters = onlyLetters.replace(onlyLetters.charAt(index), ' ');
		}
		return totalUniqueLetters;
	}

	/**
	 * Part 1e 
	 * Counts the most common letter in a string and then returns a char
	 * value of that letter by counting how many times that letter appears in the string 
	 * 
	 * @param s
	 * @return
	 */
	public static char mostCommonLetter(String s) {
		s = s.toLowerCase();
		String[] onlyLettersArray = s.split("");
		Arrays.sort(onlyLettersArray);
		s = Arrays.toString(onlyLettersArray);
		String onlyLetters = "";
		for (int index = 0; index < s.length(); index++) {
			if (isLetter(s.charAt(index)) == true) {
				onlyLetters += s.charAt(index);
			}
		}
		char mostCommonLetter = ' ';
		int letterCount = 0;
		int mostLetterOccurences = 0;
		for (int i = 0; i < onlyLetters.length() - 1; i++) {
			if (onlyLetters.charAt(i) == onlyLetters.charAt(i + 1)) {
				letterCount++;
			} else {
				letterCount = 0;
			}
			if (letterCount >= mostLetterOccurences) {
				mostLetterOccurences = letterCount;
				mostCommonLetter = onlyLetters.charAt(i);
			}
		}
		return mostCommonLetter;
	}

	/**
	 * Part 1f 
	 * This method counts all of the unique words in a sequence and then outputs the number of the 
	 * unique words
	 * 
	 * @param s
	 * @return
	 */
	public static int countUniqueWords(String s) {
		s = s.toLowerCase();
		String[] storeWords = s.split(" ");
		Arrays.sort(storeWords);
		int numOfWords = 0;
		for (int i = 0; i < storeWords.length - 1; i++) {
			if (storeWords[i] != storeWords[i + 1]) {
				numOfWords++;
			}
		}
		return numOfWords;
	}
}
