package project_EoinBusby_40365970;

public class testing extends Part1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(caesarEncrypt("Hello There!", 2));
	}
	public static boolean isLetter(char ch) {
		boolean letter;
		int myInt = (int) ch;
		if ((myInt >= 65 && myInt <= 90) || (myInt >= 97 && myInt <= 122)) {
			letter = true;
		} else {
			letter = false;
		}
		return letter;

	}
/**
 * Part 2a method 2 can
 * @param s
 * @param shift
 * @return
 */
	public static String caesarEncrypt(String s, int shift) {
		String cypher = "";
		for (int i = 0; i < s.length(); i++) {
			char c = s.charAt(i);
			if (c >= 'a' && c <= 'z') {
				int originalAlphabetPosition = c - 'a';
				int newAlphabetPosition = (originalAlphabetPosition + shift) % 26;
				char encryptedChar = (char) ('a' + newAlphabetPosition);
				cypher = cypher + encryptedChar;
			}
			if (c >= 'A' && c <= 'Z') {
				int originalAlphabetPosition = c - 'A';
				int newAlphabetPosition = (originalAlphabetPosition + shift) % 26;
				char encryptedChar = (char) ('A' + newAlphabetPosition);
				cypher = cypher + encryptedChar;
			}
			if (isLetter(c) == false) {
				cypher = cypher + c;
			}
		}
		return cypher;
	}
	
}
