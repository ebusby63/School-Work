package Part3;

import java.awt.Color;
import java.awt.Font;

import javax.swing.ImageIcon;
import console.Console;

public class QUBLibraryUpdated {
	static final String options[] = { "List All Books", "List Books By Status", "Add a Book", "Remove a Book",
			"Borrow a Book", "Return a Book", "Display Ranked List", "Exit" };
	static String title1 = "QUB Library App";
	static Library lib = new Library();
	static int bookCount = 0;
	static Console c = new Console(true);

	/**
	 * I couln't figure out how to get the console class to read int or double
	 * values so I all the menu's to accept char values for the switch cases and
	 * used parseInt and parseDouble for the addBook() method
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		c.setSize(1200, 500);
		c.setVisible(true);
		c.setBgColour(Color.BLACK);
		c.setFont(new Font("Courier", Font.BOLD, 20));
		c.setColour(Color.WHITE);

		boolean quit = false;

		do {
			char option = getUserChoice(title1, options);
			switch (option) {
			case 'A':
				listAllBooks();
				break;
			case 'a':
				listAllBooks();
				break;
			case 'B':
				listByStatus();
				break;
			case 'b':
				listByStatus();
				break;
			case 'C':
				addBook();
				break;
			case 'c':
				addBook();
				break;
			case 'D':
				removeBook();
				break;
			case 'd':
				removeBook();
				break;
			case 'E':
				borrowBook();
				break;
			case 'e':
				borrowBook();
				break;
			case 'F':
				returnBook();
				break;
			case 'f':
				returnBook();
				break;
			case 'G':
				listByPopularity();
				break;
			case 'g':
				listByPopularity();
				break;
			case 'H':
				c.println("\nApplication is closing");
				quit = true;
				break;
			case 'h':
				c.println("\nApplication is closing");
				quit = true;
				break;
			default:
				c.println("\nError - wrong input try again!");
			}
		} while (!quit);
	}

	/**
	 * Creates a list of all LibraryBook objects that are stored within the Library
	 * object
	 */
	public static void listAllBooks() {
		if (bookCount == 0) {
			c.println("\nThere's no books in the system");
			c.println();
		} else {
			LibraryBook bookList[] = new LibraryBook[bookCount];
			bookList = lib.list();
			c.println("\nA list of all the books:\n");
			for (int index = 0; index < bookCount; index++) {
				c.println(bookList[index]);
				c.print(bookList[index].getImage());
				c.println("\n");
			}
		}
	}

	/**
	 * Allows the user to list the books by the BookStatus enumeration by getting
	 * input through a menu then using the list(stat) method from the Library class
	 */
	public static void listByStatus() {
		if (bookCount == 0) {
			c.println("\nThere's no books in the system");
			c.println();
		} else {
			String statOptions[] = { "Available", "On Loan", "Withdrawn" };
			String title = "Select a Status";
			char choice = getUserChoice(title, statOptions);
			BookStatus stat;
			switch (choice) {
			case 'A':
				stat = BookStatus.AVAILABLE;
				int length = lib.list(stat).length;
				if (length == 0) {
					c.println("There is no available books in the QUB Library");
				} else {
					LibraryBook statBooks1[] = new LibraryBook[length];
					statBooks1 = lib.list(stat);
					c.println("\nA list of all the avaliable books:\n");
					for (int index = 0; index < statBooks1.length; index++) {
						c.println(statBooks1[index]);
						c.print(statBooks1[index].getImage());
						c.println("\n");
					}
				}

				break;
			case 'a':
				stat = BookStatus.AVAILABLE;
				length = lib.list(stat).length;
				if (length == 0) {
					c.println("There is no available books in the QUB Library");
				} else {
					LibraryBook statBooks1[] = new LibraryBook[length];
					statBooks1 = lib.list(stat);
					c.println("\nA list of all the avaliable books:\n");
					for (int index = 0; index < statBooks1.length; index++) {
						c.println(statBooks1[index]);
						c.print(statBooks1[index].getImage());
						c.println("\n");
					}
				}
				break;
			case 'B':
				stat = BookStatus.ON_LOAN;
				if (lib.list(stat).length == 0) {
					c.println("There is no books on loan in the QUB Library");
				} else {
					c.println("\nA list of all the books that are on loan:\n");
					LibraryBook statBooks2[] = new LibraryBook[lib.list(stat).length];
					statBooks2 = lib.list(stat);
					for (int index = 0; index < statBooks2.length; index++) {
						c.println(statBooks2[index]);
						c.print(statBooks2[index].getImage());
						c.println("\n");
					}
				}
				break;
			case 'b':
				stat = BookStatus.ON_LOAN;
				if (lib.list(stat).length == 0) {
					c.println("There is no books on loan in the QUB Library");
				} else {
					c.println("\nA list of all the books that are on loan:\n");
					LibraryBook statBooks2[] = new LibraryBook[lib.list(stat).length];
					statBooks2 = lib.list(stat);
					for (int index = 0; index < statBooks2.length; index++) {
						c.println(statBooks2[index]);
						c.print(statBooks2[index].getImage());
						c.println("\n");
					}
				}
				break;
			case 'C':
				stat = BookStatus.WITHDRAW;
				if (lib.list(stat).length == 0) {
					c.println("There is no books withdrawn in the QUB Library");
				} else {
					LibraryBook statBooks3[] = new LibraryBook[lib.list(stat).length];
					statBooks3 = lib.list(stat);
					c.println("\nA list of all the books that are withdrawn:\n");
					for (int index = 0; index < statBooks3.length; index++) {
						c.println(statBooks3[index]);
						c.print(statBooks3[index].getImage());
						c.println("\n");
					}
				}
				break;
			case 'c':
				stat = BookStatus.WITHDRAW;
				if (lib.list(stat).length == 0) {
					c.println("There is no books withdrawn in the QUB Library");
				} else {
					LibraryBook statBooks3[] = new LibraryBook[lib.list(stat).length];
					statBooks3 = lib.list(stat);
					c.println("\nA list of all the books that are withdrawn:\n");
					for (int index = 0; index < statBooks3.length; index++) {
						c.println(statBooks3[index]);
						c.print(statBooks3[index].getImage());
						c.println("\n");

					}
				}
				break;
			default:
				c.println("Error - wrong input try again!");
			}
		}
	}

	/**
	 * Adds a new LibraryBook object to the library class by asking for user input
	 * and using a menu for book type because it's an enumeration and not a string
	 * then it checks the inputs using the add() method from the Library class if
	 * the book isn't added the nextId variable in LibraryBook is reduced by one so
	 * the id still go up in increments of 1
	 * 
	 */
	public static void addBook() {
		LibraryBook bk = new LibraryBook(null, null, null, null, 0, null, 0.0);
		try {
			c.println("\nEnter the title of the book: ");
			String title = c.readLn().trim();
			bk.setTitle(title);
			c.println("\nEnter the author: ");
			String author = c.readLn().trim();
			bk.setAuthor(author);
			c.println("\nEnter the isbn: ");
			String isbn = c.readLn().trim();
			bk.setIsbn(isbn);
			title = "Choose a Book type";
			String statOptions[] = { "Fiction", "Non-fiction", "Reference" };
			BookType type;
			char choice = getUserChoice(title, statOptions);
			switch (choice) {
			case 'A':
				type = BookType.FICTION;
				c.println("\nBook Type set as Fiction");
				bk.setBookType(type);
				break;
			case 'a':
				type = BookType.FICTION;
				c.println("\nBook Type set as Fiction");
				bk.setBookType(type);
				break;
			case 'B':
				type = BookType.NON_FICTION;
				c.println("\nBook Type set as Non-fiction");
				bk.setBookType(type);
				break;
			case 'b':
				type = BookType.NON_FICTION;
				c.println("\nBook Type set as Non-fiction");
				bk.setBookType(type);
				break;
			case 'C':
				type = BookType.REFERENCE;
				c.println("\nBook Type set as reference");
				bk.setBookType(type);
				break;
			case 'c':
				type = BookType.REFERENCE;
				c.println("\nBook Type set as reference");
				bk.setBookType(type);
				break;
			default:
				c.println("\nError - a problem occured try again!");
			}
			c.println("\nEnter the edtion: ");
			String edtion = c.readLn().trim();
			int edt = Integer.parseInt(edtion);
			bk.setEdtion(edt);
			c.println("\nEnter the summary: ");
			String sum = c.readLn().trim();
			bk.setSummary(sum);
			c.println("\nEnter the Price");
			String StringPrice = c.readLn();
			double price = Double.parseDouble(StringPrice);
			bk.setPrice(price);
			c.println("\nEnter image file name:");
			ImageIcon image = new ImageIcon(c.readLn().trim());
			bk.setImageIcon(image);
			if (lib.add(bk)) {
				c.println("\nThe new book has been added\n");
				bookCount++;
			} else {
				c.println("\nThe new book didn't meet the requirements and was not added - try again!");
				LibraryBook.setNextId(bookCount + 1);
			}
		} catch (Exception ex) {
			c.println("Error - a problem occured try again!");
			LibraryBook.setNextId(bookCount + 1);
			c.readLn();
		}

	}

	/**
	 * make book be marked as withdrawn but only if they're available This doesn't
	 * work I couldn't figure out how to get it working without making another
	 * public method in the library class
	 */
	public static void removeBook() {
		if (bookCount == 0) {
			c.println("\nThere are no books in the system to remove");
			c.println();
		} else {
			LibraryBook removeBook[] = new LibraryBook[lib.list(BookStatus.AVAILABLE).length];
			removeBook = lib.list(BookStatus.AVAILABLE);
			for (int index = 0; index < removeBook.length; index++) {
				c.println(removeBook[index]);
			}
			try {
				c.println("Enter the id of the book: ");
				String StringId = c.readLn().trim();
				int id = Integer.parseInt(StringId);

				if (id > 0 && id <= bookCount) {

					LibraryBook[] target = new LibraryBook[1];
					target = lib.search(id);
					if (target[0].getStatus() == BookStatus.AVAILABLE) {

						c.println("Book ID: " + id + " has been withdrawn");
					} else {
						c.println("Book is not available to be withdrawn");
					}

				} else {
					c.println("Error - id entered is not assigned to a book try again!");
				}
			} catch (Exception ex) {
				c.println("Error - a problem occured try again!");
			}
		}

	}

	/**
	 * Sets a LibraryBook object Book Status to On Loan but only if it's already set
	 * to available it does this by using the search method to find the specific
	 * LibraryBook object and then uses the borrowBook() method to change the Book
	 * Status
	 */
	public static void borrowBook() {
		LibraryBook borrowBook[] = new LibraryBook[lib.list(BookStatus.AVAILABLE).length];
		borrowBook = lib.list(BookStatus.AVAILABLE);
		for (int index = 0; index < borrowBook.length; index++) {
			c.println(borrowBook[index]);
			c.print(borrowBook[index].getImage());
			c.println("\n");
		}
		c.println("Enter id of an available book: ");
		try {
			String StringId = c.readLn();
			int id = Integer.parseInt(StringId);

			if (id >= 0 && id <= bookCount) {
				if (lib.borrowBook(id)) {
					c.println("Book ID: " + id + " has been borrowed.");
				} else {
					c.println("Book is already on loan or withdrawn.");
				}
			} else {
				c.println("Error - id entered is not assigned to a book try again!");
			}
		} catch (Exception ex) {
			c.println("Error - a problem occured try again!");
		}
	}

	/**
	 * Sets a LibraryBook object Book Status to Available but only if it's already
	 * set to On Loan it does this by using the search method to find the specific
	 * LibraryBook object and then uses the returnBook() method to change the Book
	 * Status
	 */
	public static void returnBook() {
		LibraryBook returnBook[] = new LibraryBook[lib.list(BookStatus.ON_LOAN).length];
		returnBook = lib.list(BookStatus.ON_LOAN);
		for (int index = 0; index < returnBook.length; index++) {
			c.println(returnBook[index]);
			c.print(returnBook[index].getImage());
			c.println("\n");
		}
		c.println("Enter id of an on loan book: ");
		try {
			String StringId = c.readLn();
			int id = Integer.parseInt(StringId);

			if (id >= 0 && id <= bookCount) {
				if (lib.returnBook(id)) {
					c.println("Book ID: " + id + " was returned.");
				} else {
					c.println("The book was not on loan.");
				}
			} else {
				c.println("Error - id entered is not assigned to a book try again!");
			}
		} catch (Exception ex) {
			c.println("Error - a problem occured try again!");
		}
	}

	/**
	 * Sorts all of the objects in the Library object by the loan count of the
	 * LibraryBook object going from highest loan count to lowest
	 */
	public static void listByPopularity() {
		LibraryBook popBooks[] = new LibraryBook[bookCount];
		popBooks = lib.mostPopular();
		c.println("\nList of Books by popularity:\n");
		for (int i = 0; i < popBooks.length; i++) {
			c.println(popBooks[i]);
			c.print(popBooks[i].getImage());
			c.println("\n");
		}
	}

	public static char getUserChoice(String title, String data[]) {
		c.println(title);
		for (int i = 0; i < title.length(); i++) {
			c.print("+");
		}
		c.print("\n");
		char letter;
		for (int opt = 1; opt <= data.length; opt++) {
			letter = (char) (opt + 64);
			c.println(letter + ". " + data[opt - 1]);
		}
		c.println();
		c.println("Enter a letter: ");
		boolean choice = true;
		String value = "";
		while (choice) {
			try {
				value = c.readLn();
				value.trim();

				choice = false;
			} catch (Exception ex) {
				c.println("Invaild input try again");

			}
		}
		return value.charAt(0);
	}

}
