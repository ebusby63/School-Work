package Part3;

public interface Lendable {
	public boolean checkout();
	public boolean checkIn();
}
