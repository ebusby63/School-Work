package Part2;

public class Book {

	private String title;
	private String author;
	private String isbn;
	private BookType type;
	private int edtion;
	private String summary;
	private double price;

	public Book(String title, String auth, String isbn, BookType type, int edt, String sum, double price) {
		try {
			this.title = title;
			this.author = auth;
			this.isbn = isbn;
			this.type = type;
			this.edtion = edt;
			this.summary = sum;
			this.price = price;
		} catch (Exception ex) {
			System.out.println("Error - a problem occured try again!");
		}
	}

	public String getTitle() {
		return this.title;
	}

	public String getAuthor() {
		return this.author;
	}

	public String getIsbn() {
		return this.isbn;
	}

	public BookType getBookType() {
		return this.type;
	}

	public int getEdtion() {
		return this.edtion;
	}

	public String getSummary() {
		return this.summary;
	}

	public double getPrice() {
		return this.price;
	}

	public String toString() {
		String str = getTitle() + " by " + getAuthor() + "\nISBN: " + getIsbn() + "\nType: " + getBookType()
				+ "\nSummary: " + getSummary() + "\nPrice: £" + getPrice();
		return str;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public void setIsbn(String isbn) {
		this.isbn = isbn;
	}

	public void setBookType(BookType type) {
		this.type = type;
	}

	public void setEdtion(int edt) {
		this.edtion = edt;
	}

	public void setSummary(String sum) {
		this.summary = sum;
	}

	public void setPrice(double price) {
		this.price = price;
	}
	
}
