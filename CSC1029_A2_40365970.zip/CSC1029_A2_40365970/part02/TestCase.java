package Part2;

public class TestCase {

	public static void main(String[] args) {
		TCase28();
	}

	public static void TCase1() {
		Book bk = new Book("Title of book", "Author of book", "0987654321", BookType.FICTION, 1, "Summary of book that is good", 7.8);
		System.out.println(bk);
	}

	public static void TCase2() {
		LibraryBook libBk = new LibraryBook("Title of Book", "Author of Book", "0987654321", BookType.NON_FICTION, 8, "Summary of Book that is good", 8.9);
		System.out.println(libBk);
	}

	public static void TCase3() {
		LibraryBook libBk1 = new LibraryBook("Title of Book", "Author of Book", "0987654321", BookType.NON_FICTION, 8, "Summary of Book that is good", 8.9);
		System.out.println(libBk1);
		LibraryBook libBk2 = new LibraryBook("Title of Book", "Author of Book", "0987654321", BookType.NON_FICTION, 8, "Summary of Book that is good", 8.9);
		System.out.println(libBk2);
	}

	public static void TCase4() {
		LibraryBook libBk1 = new LibraryBook("Title of Book", "Author of Book", "0987654321", BookType.NON_FICTION, 8, "Summary of Book that is good", 8.9);
		System.out.println(libBk1);
		libBk1.checkout();
		System.out.println(libBk1);
	}

	public static void TCase5() {
		LibraryBook libBk1 = new LibraryBook("Title of Book", "Author of Book", "0987654321", BookType.NON_FICTION, 8, "Summary of Book that is good", 8.9);
		System.out.println(libBk1);
		libBk1.checkout();
		System.out.println(libBk1);
		libBk1.checkout();
		System.out.println(libBk1);
	}
	public static void TCase6() {
		LibraryBook libBk1 = new LibraryBook("Title of Book", "Author of Book", "0987654321", BookType.NON_FICTION, 8, "Summary of Book that is good", 8.9);
		libBk1.checkout();
		System.out.println(libBk1);
		libBk1.checkIn();
		System.out.println(libBk1);
	}
	public static void TCase7() {
		LibraryBook libBk1 = new LibraryBook("Title of Book", "Author of Book", "0987654321", BookType.NON_FICTION, 8, "Summary of Book that is good", 8.9);
		libBk1.checkIn();
		System.out.println(libBk1);
	}
	public static void TCase8() {
		LibraryBook libBk1 = new LibraryBook("Title of Book", "Author of Book", "0987654321", BookType.NON_FICTION, 8, "Summary of Book that is good", 8.9);
		System.out.println(libBk1);
		libBk1.checkout();
		System.out.println(libBk1);
	}
	public static void TCase9() {
		LibraryBook libBk1 = new LibraryBook("Title of Book", "Author of Book", "0987654321", BookType.REFERENCE, 8, "Summary of Book that is good", 8.9);
		LibraryBook libBk2 = new LibraryBook("Hunger Games", "Author of Book", "0987654321", BookType.FICTION, 8, "They play the hunger games", 8.9);
		LibraryBook libBk3 = new LibraryBook("100 animal facts", "John Smith", "0987654321", BookType.NON_FICTION, 8, "Has 100 animal facts", 8.9);
		Library libBooks = new Library();
		libBooks.add(libBk1);
		libBooks.add(libBk2);
		libBooks.add(libBk3);
		libBooks.borrowBook(3);
		libBooks.borrowBook(1);
		System.out.println(libBk1);
		System.out.println(libBk2);
		System.out.println(libBk3);
	}
	public static void TCase10() {
		Library libBooks = new Library();
		libBooks.borrowBook(5);
	}
	public static void TCase11() {
		LibraryBook libBk1 = new LibraryBook("Title of Book", "Author of Book", "0987654321", BookType.REFERENCE, 8, "Summary of Book that is good", 8.9);
		LibraryBook libBk2 = new LibraryBook("Hunger Games", "Author of Book", "0987654321", BookType.FICTION, 8, "They play the hunger games", 8.9);
		LibraryBook libBk3 = new LibraryBook("100 animal facts", "John Smith", "0987654321", BookType.NON_FICTION, 8, "Has 100 animal facts", 8.9);
		Library libBooks = new Library();
		libBooks.add(libBk1);
		libBooks.add(libBk2);
		libBooks.add(libBk3);
		libBooks.borrowBook(1);
		libBooks.borrowBook(3);
		libBooks.returnBook(3);
		System.out.println(libBk1);
		System.out.println(libBk2);
		System.out.println(libBk3);
	}
	public static void TCase12() {
		Library libBooks = new Library();
		libBooks.returnBook(5);
	}
	public static void TCase13() {
		Library libBooks = new Library();
		LibraryBook libBk1 = new LibraryBook("Title of Book", "Author of Book", "0987654321", BookType.REFERENCE, 8, "Summary of Book that is good", 8.9);
		LibraryBook libBk2 = new LibraryBook("Hunger Games", "Author of Book", "0987654321", BookType.FICTION, 8, "They play the hunger games", 8.9);
		LibraryBook libBk3 = new LibraryBook("100 animal facts", "John Smith", "0987654321", BookType.NON_FICTION, 8, "Has 100 animal facts", 8.9);
		libBooks.add(libBk1);
		libBooks.add(libBk2);
		libBooks.add(libBk3);
		int length = libBooks.list().length;
		LibraryBook[] bookList = new LibraryBook[length];
		bookList = libBooks.list();
		for(int i = 0;i < length; i++) {
			System.out.println(bookList[i]);
		}
	}
	public static void TCase14() {
		Library libBooks = new Library();
		int length = libBooks.list().length;
		LibraryBook[] bookList = new LibraryBook[length];
		bookList = libBooks.list();
		for(int i = 0;i < length; i++) {
			System.out.println(bookList[i]);
		}
	}
	public static void TCase15() {
		Library libBooks = new Library();
		LibraryBook libBk1 = new LibraryBook("Title of Book", "Author of Book", "0987654321", BookType.REFERENCE, 8, "Summary of Book that is good", 8.9);
		LibraryBook libBk2 = new LibraryBook("Hunger Games", "Author of Book", "0987654321", BookType.FICTION, 8, "They play the hunger games", 8.9);
		LibraryBook libBk3 = new LibraryBook("100 animal facts", "John Smith", "0987654321", BookType.NON_FICTION, 8, "Has 100 animal facts", 8.9);
		libBooks.add(libBk1);
		libBooks.add(libBk2);
		libBooks.add(libBk3);
		libBooks.borrowBook(2);
		BookStatus stat = BookStatus.AVAILABLE;
		int length = libBooks.list(stat).length;
		LibraryBook[] bookList = new LibraryBook[length];
		bookList = libBooks.list(stat);
		for(int i = 0;i < length; i++) {
			System.out.println(bookList[i]);
		}
	}
	public static void TCase16() {
		Library libBooks = new Library();
		LibraryBook libBk1 = new LibraryBook("Title of Book", "Author of Book", "0987654321", BookType.REFERENCE, 8, "Summary of Book that is good", 8.9);
		LibraryBook libBk2 = new LibraryBook("Hunger Games", "Author of Book", "0987654321", BookType.FICTION, 8, "They play the hunger games", 8.9);
		LibraryBook libBk3 = new LibraryBook("100 animal facts", "John Smith", "0987654321", BookType.NON_FICTION, 8, "Has 100 animal facts", 8.9);
		libBooks.add(libBk1);
		libBooks.add(libBk2);
		libBooks.add(libBk3);
		libBooks.borrowBook(2);
		libBooks.returnBook(2);
		libBooks.borrowBook(2);
		libBooks.borrowBook(3);
		int length = libBooks.mostPopular().length;
		LibraryBook[] bookList = new LibraryBook[length];
		bookList = libBooks.mostPopular();
		for(int i = 0;i < length; i++) {
			System.out.println(bookList[i]);
		}
	}
	public static void TCase17() {
		Library libBooks = new Library();
		LibraryBook libBk1 = new LibraryBook("Title of Book", "Author of Book", "0987654321", BookType.REFERENCE, 8, "Summary of Book that is good", 8.9);
		LibraryBook libBk2 = new LibraryBook("Hunger Games", "Author of Book", "0987654321", BookType.FICTION, 8, "They play the hunger games", 8.9);
		LibraryBook libBk3 = new LibraryBook("100 animal facts", "John Smith", "0987654321", BookType.NON_FICTION, 8, "Has 100 animal facts", 8.9);
		libBooks.add(libBk1);
		libBooks.add(libBk2);
		libBooks.add(libBk3);
		int length = libBooks.mostPopular().length;
		LibraryBook[] bookList = new LibraryBook[length];
		bookList = libBooks.mostPopular();
		for(int i = 0;i < length; i++) {
			System.out.println(bookList[i]);
		}
	}
	public static void TCase18() {
		Library libBooks = new Library();
		LibraryBook libBk1 = new LibraryBook("Title of Book", "Author of Book", "0987654321", BookType.REFERENCE, 8, "Summary of Book that is good", 8.9);
		LibraryBook libBk2 = new LibraryBook("Hunger Games", "Author of Book", "0987654321", BookType.FICTION, 8, "They play the hunger games", 8.9);
		LibraryBook libBk3 = new LibraryBook("100 animal facts", "John Smith", "0987654321", BookType.NON_FICTION, 8, "Has 100 animal facts", 8.9);
		libBooks.add(libBk1);
		libBooks.add(libBk2);
		libBooks.add(libBk3);
		LibraryBook[] searchResult = new LibraryBook[1];
		searchResult = libBooks.search(3);
		System.out.println(searchResult[0]);
	}
	public static void TCase19() {
		Library libBooks = new Library();
		LibraryBook[] searchResult = new LibraryBook[1];
		searchResult = libBooks.search(3);
		System.out.println(searchResult[0]);
	}
	public static void TCase20() {
		Library libBooks = new Library();
		LibraryBook libBk3 = new LibraryBook("100 animal facts", "John Smith", "0987654321", BookType.NON_FICTION, 8, "Has 100 animal facts", 8.9);
		libBooks.add(libBk3);
		int length = libBooks.list().length;
		LibraryBook[] bookList = new LibraryBook[length];
		bookList = libBooks.list();
		for(int i = 0;i < length; i++) {
			System.out.println(bookList[i]);
		}
	}
	public static void TCase21() {
		Library libBooks = new Library();
		LibraryBook libBk3 = new LibraryBook(" ", "John Smith", "0987654321", BookType.NON_FICTION, 8, "Has 100 animal facts", 8.9);
		libBooks.add(libBk3);
		int length = libBooks.list().length;
		LibraryBook[] bookList = new LibraryBook[length];
		bookList = libBooks.list();
		for(int i = 0;i < length; i++) {
			System.out.println(bookList[i]);
		}
	}
	public static void TCase22() {
		Library libBooks = new Library();
		LibraryBook libBk3 = new LibraryBook("100 Animal Facts", "", "0987654321", BookType.NON_FICTION, 8, "Has 100 animal facts", 8.9);
		libBooks.add(libBk3);
		int length = libBooks.list().length;
		LibraryBook[] bookList = new LibraryBook[length];
		bookList = libBooks.list();
		for(int i = 0;i < length; i++) {
			System.out.println(bookList[i]);
		}
	}
	public static void TCase23() {
		Library libBooks = new Library();
		LibraryBook libBk3 = new LibraryBook("100 Animal Facts", "John Smith", "87654321", BookType.NON_FICTION, 8, "Has 100 animal facts", 8.9);
		libBooks.add(libBk3);
		int length = libBooks.list().length;
		LibraryBook[] bookList = new LibraryBook[length];
		bookList = libBooks.list();
		for(int i = 0;i < length; i++) {
			System.out.println(bookList[i]);
		}
	}
	public static void TCase24() {
		Library libBooks = new Library();
		LibraryBook libBk3 = new LibraryBook("100 Animal Facts", "John Smith", "0987654321", BookType.NON_FICTION, 8, "", 8.9);
		libBooks.add(libBk3);
		int length = libBooks.list().length;
		LibraryBook[] bookList = new LibraryBook[length];
		bookList = libBooks.list();
		for(int i = 0;i < length; i++) {
			System.out.println(bookList[i]);
		}
	}
	public static void TCase25() {
		Library libBooks = new Library();
		LibraryBook libBk3 = new LibraryBook("100 Animal Facts", "John Smith", "0987654321", BookType.NON_FICTION, 8, "Has 100 animal facts", 0);
		libBooks.add(libBk3);
		int length = libBooks.list().length;
		LibraryBook[] bookList = new LibraryBook[length];
		bookList = libBooks.list();
		for(int i = 0;i < length; i++) {
			System.out.println(bookList[i]);
		}
	}
	public static void TCase26() {
		Library libBooks = new Library();
		LibraryBook libBk1 = new LibraryBook("Title of Book", "Author of Book", "0987654321", BookType.REFERENCE, 8, "Summary of Book that is good", 8.9);
		LibraryBook libBk2 = new LibraryBook("Hunger Games", "Author of Book", "0987654321", BookType.FICTION, 8, "They play the hunger games", 8.9);
		
		libBooks.add(libBk1);
		libBooks.add(libBk2);
	
		libBooks.borrowBook(1);
		BookStatus stat = BookStatus.ON_LOAN;
		int length = libBooks.list(stat).length;
		LibraryBook[] bookList1 = new LibraryBook[length];
		bookList1 = libBooks.list(stat);
		for(int i = 0;i < length; i++) {
			System.out.println(bookList1[i]);
		}
	}
	public static void TCase27() {
		Library libBooks = new Library();
		LibraryBook libBk1 = new LibraryBook("Title of Book", "Author of Book", "0987654321", BookType.REFERENCE, 8, "Summary of Book that is good", 8.9);
		LibraryBook libBk2 = new LibraryBook("Hunger Games", "Author of Book", "0987654321", BookType.FICTION, 8, "They play the hunger games", 8.9);
		libBk2.setBookStatus(BookStatus.WITHDRAW);
		libBooks.add(libBk1);
		libBooks.add(libBk2);
		BookStatus stat = BookStatus.WITHDRAW;
		int length = libBooks.list(stat).length;
		LibraryBook[] bookList1 = new LibraryBook[length];
		bookList1 = libBooks.list(stat);
		for(int i = 0;i < length; i++) {
			System.out.println(bookList1[i]);
		}
	}
	public static void TCase28() {
		Library libBooks = new Library();
		LibraryBook libBk3 = new LibraryBook("100 Animal Facts", "John Smith", "099987654321", BookType.NON_FICTION, 8, "Has 100 animal facts", 8.9);
		libBooks.add(libBk3);
		int length = libBooks.list().length;
		LibraryBook[] bookList = new LibraryBook[length];
		bookList = libBooks.list();
		for(int i = 0;i < length; i++) {
			System.out.println(bookList[i]);
		}
	}
 }
