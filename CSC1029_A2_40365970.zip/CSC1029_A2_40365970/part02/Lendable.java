package Part2;

public interface Lendable {
	public boolean checkout();
	public boolean checkIn();
}
