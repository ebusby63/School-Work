package Part2;

public enum BookStatus {
	AVAILABLE("Available"),
	ON_LOAN("On Loan"),
	WITHDRAW("Withdrawen");
	
	private String info;
	private BookStatus(String str) {
		info = str;
	}
	public String toString () {
		return info;
	}
}
