package Part2;

import java.util.Scanner;

import javax.swing.ImageIcon;

public class QUBLibrary {

	static final String options[] = { "List All Books", "List Books By Status", "Add a Book", "Remove a Book",
			"Borrow a Book", "Return a Book", "Display Ranked List", "Exit" };
	static String title = "QUB Library App";
	static Library lib = new Library();
	static Scanner input = new Scanner(System.in);
	static int bookCount = 0;

	public static void main(String[] args) {
		boolean quit = false;
		Menu myMenu = new Menu(title, options);
		do {
			int option = myMenu.getUserChoice();
			switch (option) {
			case 1:
				listAllBooks();
				break;
			case 2:
				listByStatus();
				break;
			case 3:
				addBook();
				break;
			case 4:
				removeBook();
				break;
			case 5:
				borrowBook();
				break;
			case 6:
				returnBook();
				break;
			case 7:
				listByPopularity();
				break;
			case 8:
				quit = true;
				break;
			default:
				System.out.println("Error - wrong input try again!");
			}

		} while (!quit);

	}

	/**
	 * Creates a list of all LibraryBook objects that are stored within the Library object
	 */
	public static void listAllBooks() {
		if (bookCount == 0) {
			System.out.println("\nThere's no books in the system");
			System.out.println();
		} else {
			LibraryBook bookList[] = new LibraryBook[bookCount];
			bookList = lib.list();
			System.out.println("\nA list of all the books:\n");
			for (int index = 0; index < bookCount; index++) {
				System.out.println(bookList[index]);
			}
		}
	}

	/**
	 * Allows the user to list the books by the BookStatus enumeration by getting
	 * input through a menu then using the list(stat) method from the Library class
	 */
	public static void listByStatus() {
		if (bookCount == 0) {
			System.out.println("\nThere's no books in the system");
			System.out.println();
		} else {
			String statOptions[] = { "Available", "On Loan", "Withdrawn" };
			String title = "Select a Status";
			Menu statMenu = new Menu(title, statOptions);
			int choice = statMenu.getUserChoice();
			BookStatus stat;
			switch (choice) {
			case 1:
				stat = BookStatus.AVAILABLE;
				int length = lib.list(stat).length;
				if (length == 0) {
					System.out.println("There is no available books in the QUB Library");
				} else {
					LibraryBook statBooks1[] = new LibraryBook[length];
					statBooks1 = lib.list(stat);
					System.out.println("\nA list of all the avaliable books:\n");
					for (int index = 0; index < statBooks1.length; index++) {
						System.out.println(statBooks1[index]);
					}
				}
				break;
			case 2:
				stat = BookStatus.ON_LOAN;
				if (lib.list(stat).length == 0) {
					System.out.println("There is no books on loan in the QUB Library");
				} else {
					System.out.println("\nA list of all the books that are on loan:\n");
					LibraryBook statBooks2[] = new LibraryBook[lib.list(stat).length];
					statBooks2 = lib.list(stat);
					for (int index = 0; index < statBooks2.length; index++) {
						System.out.println(statBooks2[index]);
					}
				}
				break;
			case 3:
				stat = BookStatus.WITHDRAW;
				if (lib.list(stat).length == 0) {
					System.out.println("There is no books withdrawn in the QUB Library");
				} else {
					LibraryBook statBooks3[] = new LibraryBook[lib.list(stat).length];
					statBooks3 = lib.list(stat);
					System.out.println("\nA list of all the books that are withdrawn:\n");
					for (int index = 0; index < statBooks3.length; index++) {
						System.out.println(statBooks3[index]);
					}
				}
				break;
			default:
				System.out.println("Error - wrong input try again!");
			}
		}
	}

	/**
	 * Adds a new LibraryBook object to the library class by asking for user input
	 * and using a menu for book type because it's an enumeration and not a string
	 * then it checks the inputs using the add() method from the Library class if the book isn't 
	 * added the nextId variable in LibraryBook is reduced by one so the id still go up in increments of 1
	 */
	public static void addBook() {
		LibraryBook bk = new LibraryBook(null, null, null, null, 0, null, 0.0);
		try {
			System.out.println("\nEnter the title of the book: ");
			String title = input.nextLine().trim();
			bk.setTitle(title);
			System.out.println("\nEnter the author: ");
			String author = input.nextLine().trim();
			bk.setAuthor(author);
			System.out.println("\nEnter the isbn: ");
			String isbn = input.nextLine().trim();
			bk.setIsbn(isbn);
			title = "Choose a Book type";
			String statOptions[] = { "Fiction", "Non-fiction", "Reference" };
			Menu statMenu = new Menu(title, statOptions);
			BookType type;
			int choice = statMenu.getUserChoice();
			switch (choice) {
			case 1:
				type = BookType.FICTION;
				System.out.println("\nBook Type set as Fiction");
				bk.setBookType(type);
				break;
			case 2:
				type = BookType.NON_FICTION;
				System.out.println("\nBook Type set as Non-fiction");
				bk.setBookType(type);
				break;
			case 3:
				type = BookType.REFERENCE;
				System.out.println("\nBook Type set as reference");
				bk.setBookType(type);
				break;
			default:
				System.out.println("Error - a problem occured try again!");
			}
			System.out.println("\nEnter the edtion: ");
			int edt = 0;
			edt = input.nextInt();
			input.nextLine();
			bk.setEdtion(edt);
			System.out.println("\nEnter the summary: ");
			String sum = input.nextLine().trim();
			bk.setSummary(sum);
			System.out.println("\nEnter the Price");
			double price = input.nextDouble();
			input.nextLine();
			bk.setPrice(price);
			System.out.println("\nEnter image file name:");
			ImageIcon image = new ImageIcon(input.nextLine());
			bk.setImageIcon(image);
			if (lib.add(bk)) {
				System.out.println("\nThe new book has been added\n");
				bookCount++;
			} else {
				System.out.println("\nThe new book didn't meet the requirements and was not added - try again!");
				LibraryBook.setNextId(bookCount+1);
			}
		} catch (Exception ex) {
			System.out.println("Error - a problem occured try again!");
			LibraryBook.setNextId(bookCount+1);
			input.nextLine();
		}

	}

	/**
	 * make book be marked as withdrawn but only if they're available This doesn't
	 * work I couldn't figure out how to get it working without making another
	 * public method in the library class
	 */
	public static void removeBook() {
		if (bookCount == 0) {
			System.out.println("\nThere are no books in the system to remove");
			System.out.println();
		} else {
			LibraryBook removeBook[] = new LibraryBook[lib.list(BookStatus.AVAILABLE).length];
			removeBook = lib.list(BookStatus.AVAILABLE);
			for (int index = 0; index < removeBook.length; index++) {
				System.out.println(removeBook[index]);
			}
			try {
				System.out.println("Enter the id of the book: ");
				int id = input.nextInt();
				input.nextLine();
				if (id > 0 && id <= bookCount) {

					LibraryBook[] target = new LibraryBook[1];
					target = lib.search(id);
					if (target[0].getStatus() == BookStatus.AVAILABLE) {

						System.out.println("Book ID: " + id + " has been withdrawn");
					} else {
						System.out.println("Book is not available to be withdrawn");
					}

				} else {
					System.out.println("Error - id entered is not assigned to a book try again!");
				}
			} catch (Exception ex) {
				System.out.println("Error - a problem occured try again!");
			}
		}

	}
	/**
	 * Sets a LibraryBook object Book Status to On Loan but only if it's already set to available
	 * it does this by using the search method to find the specific LibraryBook object and then
	 * uses the borrowBook() method to change the Book Status
	 */
	public static void borrowBook() {
		LibraryBook borrowBook[] = new LibraryBook[lib.list(BookStatus.AVAILABLE).length];
		borrowBook = lib.list(BookStatus.AVAILABLE);
		for (int index = 0; index < borrowBook.length; index++) {
			System.out.println(borrowBook[index]);
		}
		System.out.println("Enter id of an available book: ");
		try {
			int id = input.nextInt();
			input.nextLine();
			if (id >= 0 && id <= bookCount) {
				if (lib.borrowBook(id)) {
					System.out.println("Book ID: " + id + " has been borrowed.");
				} else {
					System.out.println("Book is already on loan or withdrawn.");
				}
			} else {
				System.out.println("Error - id entered is not assigned to a book try again!");
			}
		} catch (Exception ex) {
			System.out.println("Error - a problem occured try again!");
		}
	}
	/**
	 * Sets a LibraryBook object Book Status to Available but only if it's already set to On Loan
	 * it does this by using the search method to find the specific LibraryBook object and then
	 * uses the returnBook() method to change the Book Status
	 */
	public static void returnBook() {
		LibraryBook returnBook[] = new LibraryBook[lib.list(BookStatus.ON_LOAN).length];
		returnBook = lib.list(BookStatus.ON_LOAN);
		for (int index = 0; index < returnBook.length; index++) {
			System.out.println(returnBook[index]);
		}
		System.out.println("Enter id of an on loan book: ");
		try {
			int id = input.nextInt();
			input.nextLine();
			if (id >= 0 && id <= bookCount) {
				if (lib.returnBook(id)) {
					System.out.println("Book ID: " + id + " was returned.");
				} else {
					System.out.println("The book was not on loan.");
				}
			} else {
				System.out.println("Error - id entered is not assigned to a book try again!");
			}
		} catch (Exception ex) {
			System.out.println("Error - a problem occured try again!");
		}
	}
	/**
	 * Sorts all of the objects in the Library object by the loan count of the LibraryBook object 
	 * going from highest loan count to lowest
	 */
	public static void listByPopularity() {
		LibraryBook popBooks[] = new LibraryBook[bookCount];
		popBooks = lib.mostPopular();
		System.out.println("\nList of Books by popularity:\n");
		for (int i = 0; i < popBooks.length; i++) {
			System.out.println(popBooks[i] + "\n");
		}
	}
}
