package Part1;

import java.util.ArrayList;

public class Library {
	private ArrayList<LibraryBook> books = new ArrayList<LibraryBook>();

	/**
	 * Creates an instance of the library class
	 */
	public Library() {
	}

	/**
	 * Checks if a LibraryBook at a specific id is available and if it is then it
	 * will change it's Book Status to On Loan
	 */
	public boolean borrowBook(int id) {
		id--;
		boolean borrowed = false;
		try {
			if (books.get(id).getStatus() == BookStatus.AVAILABLE) {
				LibraryBook[] target = new LibraryBook[1];
				target[0] = search(id)[0];
				if (books.get(id).checkout()) {
					borrowed = true;
				}
			}
		} catch (Exception ex) {
			return borrowed;
		}
		return borrowed;
	}

	/**
	 * Checks if a LibraryBook at a specific id is On Loan and if it is then it will
	 * change it's Book Status to Available
	 */
	public boolean returnBook(int id) {
		id--;
		boolean returned = false;
		try {
			if (books.get(id).getStatus() == BookStatus.ON_LOAN) {
				LibraryBook[] target = new LibraryBook[1];
				target[0] = search(id)[0];
				if (books.get(id).checkIn()) {
					returned = true;
				}
			}
		} catch (Exception ex) {
			return returned;
		}
		return returned;
	}

	/**
	 * Returns an array of all LibraryBook objects held within the library class
	 */
	public LibraryBook[] list() {

		LibraryBook[] libBooks = new LibraryBook[books.size()];
		for (int index = 0; index < books.size(); index++) {
			libBooks[index] = books.get(index);
		}
		return libBooks;
	}

	/**
	 * Returns an array of LibraryBook objects that are group together by their book
	 * status
	 */
	public LibraryBook[] list(BookStatus stat) {
		ArrayList<LibraryBook> statBook = new ArrayList<LibraryBook>();
		LibraryBook[] libBooks;
		for (int index = 0; index < books.size(); index++) {
			if (books.get(index).getStatus() == stat) {
				statBook.add(books.get(index));
			}
		}
		libBooks = new LibraryBook[statBook.size()];
		for (int index = 0; index < statBook.size(); index++) {
			libBooks[index] = statBook.get(index);
		}
		return libBooks;
	}

	/**
	 * Returns an array of LibraryBook objects sorted by loan count from highest to
	 * lowest using a bubble sort
	 */
	public LibraryBook[] mostPopular() {
		LibraryBook[] libBooks = new LibraryBook[books.size()];
		for (int index = 0; index < libBooks.length; index++) {
			libBooks[index] = books.get(index);
		}
		int swaps = 0;
		do {
			swaps = 0;
			for (int i = 0; i < libBooks.length - 1; i++) {
				if (libBooks[i].getLoanCount() < libBooks[i + 1].getLoanCount()) {
					LibraryBook temp = new LibraryBook(null, null, null, null, 0, null, 0.0);
					temp = libBooks[i];
					libBooks[i] = libBooks[i + 1];
					libBooks[i + 1] = temp;
					swaps++;
				}
			}
		} while (swaps > 0);
		return libBooks;
	}

	/**
	 * Returns an array of a specific LibraryBook object by using a pivot search
	 */
	public LibraryBook[] search(int id) {

		LibraryBook[] libBooks = new LibraryBook[1];
		id--;
		int start = 0;
		int end = books.size() - 1;
		int pivot;
		try {
			do {
				pivot = start + ((end - start) / 2);
				if (books.get(pivot).getID() == id) {
					libBooks[0] = books.get(pivot);
					return libBooks;
				}
				if (books.get(pivot).getID() > id) {
					end = pivot - 1;
				} else {
					start = pivot + 1;
				}
			} while (start <= end);
		} catch (Exception ex) {
			return libBooks;
		}
		return libBooks;
	}

	/**
	 * Checks the validity of a LibraryBook object and if it passes all the checks
	 * it will be added to the Array list
	 */

	public boolean add(LibraryBook bk) {
		boolean added = true;
		if (bk.getImage() == null) {
			added = false;
		}
		if (bk.getAuthor().length() < 9 || bk.getAuthor().length() > 101) {
			added = false;
		}
		if (bk.getTitle().length() < 9 || bk.getTitle().length() > 101) {
			added = false;
		}
		if (bk.getIsbn().length() != 10) {
			added = false;
		}
		if (bk.getSummary().length() < 19 || bk.getSummary().length() > 151) {
			added = false;
		}
		if (bk.getPrice() <= 0.0) {
			added = false;
		}
		if (added == true) {
			books.add(bk);
		}

		return added;

	}

}