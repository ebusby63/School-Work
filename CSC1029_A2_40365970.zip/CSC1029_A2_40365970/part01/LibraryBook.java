package Part1;

import javax.swing.ImageIcon;

public class LibraryBook extends Book implements Lendable {
	private int id;
	private static int nextId = 1;
	private BookStatus status;
	private ImageIcon image;
	private int loanCount;

	public LibraryBook(String title, String author, String isbn, BookType type, int edtion, String summary,
			double price) {
		super(title, author, isbn, type, edtion, summary, price);
		this.id = LibraryBook.nextId;
		this.status = BookStatus.AVAILABLE;
		this.loanCount = 0;
		this.image = new ImageIcon("red_back.png");
		LibraryBook.nextId++;
	}

	public String toString() {
		String result = "ID: " + this.id + "\nTitle: " + this.getTitle() + "\nAuthor: " + this.getAuthor() + "\nIsbn: "
				+ this.getIsbn() + "\nBook status: " +this.getStatus()+"\nBook Type: " + this.getBookType() + 
				"\nEdtion: " + this.getEdtion() + "\nSummary: "	+ this.getSummary() + "\nPrice: £" + this.getPrice() 
				+ "\nLoan Count: " + this.loanCount + "\nImage: "+this.getImage()+"\n";
		return result;
	}
	
	public BookStatus getStatus() {
		return this.status;
	}

	public void setBookStatus(BookStatus stat) {
		this.status = stat;
	}

	public void setImageIcon(ImageIcon image) {
		this.image = image;
	}
	
	public ImageIcon getImage() {
		return this.image;
	}
	public int getID() {
		return this.id;
	}
	public int getLoanCount(){
		return this.loanCount;
	}
	public boolean checkout() {
		boolean checkedOut = false;
		if (this.status == BookStatus.AVAILABLE) {
			this.status = BookStatus.ON_LOAN;
			this.loanCount++;
			checkedOut = true;
		}
		return checkedOut;
	}

	public boolean checkIn() {
		boolean checkedIn = false;
		if (this.status == BookStatus.ON_LOAN || this.status == BookStatus.WITHDRAW) {
			this.status = BookStatus.AVAILABLE;
			checkedIn = true;
		}
		return checkedIn;
	}
	public static void setNextId(int nextId) {
		LibraryBook.nextId = nextId;
		}
	
}
